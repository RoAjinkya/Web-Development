/**
 * 
 */

function setvalue( id,name,address){
	document.getElementById("venderId").value = id;
	document.getElementById("venderName").value = name;
	document.getElementById("venderAddress").value = address;
	
	
}

