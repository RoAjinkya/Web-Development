/**
 * 
 */


function setvalue( id,name,address){
	document.getElementById("warehouseid").value = id;
	document.getElementById("warehouseName").value = name;
	document.getElementById("watehouseAddress").value = address;
	
	
}