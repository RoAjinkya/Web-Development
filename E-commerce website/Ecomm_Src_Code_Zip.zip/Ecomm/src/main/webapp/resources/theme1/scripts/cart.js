/**
 * 
 */
function calculateTotalPrice(p1, p2) {
    
	alert("hi");
	return p1 * p2;              // The function returns the product of p1 and p2
}