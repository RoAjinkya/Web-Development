package edu.neu.ecomm.sevice;

import java.util.Collection;
import java.util.List;

import edu.neu.ecomm.vo.Venders;

public interface ManageVendersService {

	void addVenders(Venders venders);

	Collection<Venders> getVenders(Venders venders);

	void deleteVender(int id);

}
