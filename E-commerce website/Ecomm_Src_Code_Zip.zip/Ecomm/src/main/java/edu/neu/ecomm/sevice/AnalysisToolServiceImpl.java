package edu.neu.ecomm.sevice;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.neu.ecomm.dao.AnalysisToolDAO;
import edu.neu.ecomm.dao.AnalysisToolDAOImpl;
import edu.neu.ecomm.vo.Stock;

@Service
public class AnalysisToolServiceImpl implements AnalysisToolService{
	@Autowired
	private AnalysisToolDAO analysisToolDAO;

	@Override
	public Collection<ArrayList<Stock>> getAnalysisTools() {
		// TODO Auto-generated method stub
		return analysisToolDAO.getAnalysisTools();
	}
	

}
