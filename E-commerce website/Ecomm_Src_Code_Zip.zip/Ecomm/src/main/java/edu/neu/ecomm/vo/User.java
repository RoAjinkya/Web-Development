package edu.neu.ecomm.vo;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
@Entity
public class User {
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@NotNull
	@Size(min=1,max=15)
	private String firstName;
	@NotNull
	@Size(min=1,max=15)
	private String lastName;
	@Lob
	private Integer phNumber;
	@NotNull
	@Email
	private String emailId;
	@NotNull
	@Size(min=5,max=10)
	private String username;
	@NotNull
	@Size(min=5,max=10)
	private String password;
	@NotNull
	@Size(min=1,max=50)
	private String shippingAddress;
	@NotNull
	@Size(min=1,max=6)
	private String pin;
	private String role;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Integer getPhNumber() {
		return phNumber;
	}
	public void setPhNumber(Integer phNumber) {
		this.phNumber = phNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	
	
	public int assignId() {
		this.id = idSequence.incrementAndGet();
		return id;
	}
	public String getRole() {
		return role;
	}
	public void setRoll(String role) {
		this.role = role;
	}
	private static final AtomicInteger idSequence = new AtomicInteger();

	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", phNumber=" + phNumber
				+ ", emailId=" + emailId + ", username=" + username + ", password=" + password + ", shippingAddress="
				+ shippingAddress + ", pin=" + pin + ", role=" + role + "]";
	}
	

}
