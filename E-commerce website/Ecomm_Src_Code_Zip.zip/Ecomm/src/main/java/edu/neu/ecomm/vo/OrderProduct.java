package edu.neu.ecomm.vo;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
@Embeddable
public class OrderProduct {
	@Column(name="productName")
	private String productName;
	@Column(name="productCategoryId")
	private Integer productCategoryId;
	@Column(name="productSubCategoryId")
	private Integer productSubCategoryId;
	@Lob
	@Column(name="quantity")
	private Integer quantity;
	@Column(name="supplierName")
	private String supplierName;
	@Column(name="warehouseName")
	private String warehouseName;
	@Lob
	@Column(name="productDesc")
	private String productDesc;
	@Column(name="productPrice")
	private Float productPrice;
	
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getProductCategoryId() {
		return productCategoryId;
	}
	public void setProductCategoryId(Integer productCategoryId) {
		this.productCategoryId = productCategoryId;
	}
	public Integer getProductSubCategoryId() {
		return productSubCategoryId;
	}
	public void setProductSubCategoryId(Integer productSubCategoryId) {
		this.productSubCategoryId = productSubCategoryId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getWarehouseName() {
		return warehouseName;
	}
	public void setWarehouseName(String warehouseName) {
		this.warehouseName = warehouseName;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public Float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Float productPrice) {
		this.productPrice = productPrice;
	}
	
	
	
	
	
}
