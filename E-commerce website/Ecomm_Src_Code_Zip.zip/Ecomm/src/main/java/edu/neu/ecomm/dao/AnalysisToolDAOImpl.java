package edu.neu.ecomm.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import edu.neu.ecomm.vo.Stock;

@Repository
public class AnalysisToolDAOImpl implements AnalysisToolDAO{

	
	@Override
	public Collection<ArrayList<Stock>> getAnalysisTools() {
		// TODO Auto-generated method stub
		Collection<ArrayList<Stock>>  listsOfStock = new ArrayList<ArrayList<Stock>>();
		Collection<Stock> mostSellingList =new ArrayList<Stock>() ;
		Collection<Stock> leastSellingList  =new ArrayList<Stock>() ;
		Collection<Stock> newlyAddedList  =new ArrayList<Stock>();
		
		try {
			final Session session = HibernetUtil.getHibernateSession();
			Transaction tx = session.beginTransaction();
			//session.save(venders);
			
			leastSellingList =session.createQuery("from Stock").list();
			mostSellingList = session.createQuery("from Stock").list();
			newlyAddedList = session.createQuery("from Stock").list();
			 tx.commit();
			 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 System.out.println(newlyAddedList.toString());
			// if(newlyAddedList!=null)
				
			listsOfStock.add((ArrayList<Stock>) newlyAddedList);
			
		
		listsOfStock.add((ArrayList<Stock>) mostSellingList);
		listsOfStock.add((ArrayList<Stock>) leastSellingList);
		
		
		System.out.println(newlyAddedList.toString());
		return listsOfStock;
	}

}
