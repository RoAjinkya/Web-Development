package edu.neu.ecomm.dao;

import java.util.Collection;

import edu.neu.ecomm.vo.OrderIn;
import edu.neu.ecomm.vo.User;
import edu.neu.ecomm.vo.Venders;
import edu.neu.ecomm.vo.Warehouse;

public interface ManageOrderDAO {

	Collection<OrderIn> getOrders(User user);

	void deleteOrder(int id);

	
	

}
