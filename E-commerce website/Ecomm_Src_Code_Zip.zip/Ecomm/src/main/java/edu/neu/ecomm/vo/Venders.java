package edu.neu.ecomm.vo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Venders {
 	@Id
 	@GeneratedValue(strategy=GenerationType.AUTO) 
	private int id;
 	@NotNull
 	@Size(min=1,max=20)
	private String venderName;
 	@NotNull
 	@Size(min=1,max=25)
	private String venderAddress;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getVenderName() {
		return venderName;
	}
	public void setVenderName(String venderName) {
		this.venderName = venderName;
	}
	public String getVenderAddress() {
		return venderAddress;
	}
	public void setVenderAddress(String venderAddress) {
		this.venderAddress = venderAddress;
	}
	@Override
	public String toString() {
		return "Venders [id=" + id + ", venderName=" + venderName + ", venderAddress=" + venderAddress + "]";
	}
	
	
}
