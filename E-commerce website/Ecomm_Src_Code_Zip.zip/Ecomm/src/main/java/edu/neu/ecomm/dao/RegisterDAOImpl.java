package edu.neu.ecomm.dao;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import edu.neu.ecomm.vo.User;

@Repository
public class RegisterDAOImpl implements RegisterDAO{

	
	@Override
	public void addStudent(User user) {
		// TODO Auto-generated method stub
		System.out.println("in DAO" + user.toString());
		final Session session = HibernetUtil.getHibernateSession();
		Transaction tx = session.beginTransaction();
		session.save(user);
		 tx.commit();
		 session.close();
		 //session.beginTransaction();
		
	/*	SessionFactory sessionFactorry = new Configuration().configure().buildSessionFactory();
		Session  session = sessionFactorry.openSession();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();*/
	}

}
