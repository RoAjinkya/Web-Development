package edu.neu.ecomm.sevice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.neu.ecomm.dao.LoginDAO;
import edu.neu.ecomm.dao.LoginDAOImpl;
import edu.neu.ecomm.vo.User;

@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
	private LoginDAO  loginDAO;

	@Override
	public User ValidateUser(User user) {
		// TODO Auto-generated method stub
		
		return loginDAO.ValidateUser(user);
		
	}

}
