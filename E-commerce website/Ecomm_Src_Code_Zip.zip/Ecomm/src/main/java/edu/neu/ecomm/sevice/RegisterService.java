package edu.neu.ecomm.sevice;

import edu.neu.ecomm.vo.User;

public interface RegisterService {

	void addUser(User user);

}
