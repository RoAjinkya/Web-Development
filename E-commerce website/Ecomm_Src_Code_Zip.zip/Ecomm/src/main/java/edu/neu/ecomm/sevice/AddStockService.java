package edu.neu.ecomm.sevice;

import edu.neu.ecomm.vo.Stock;

public interface AddStockService {

	void addStock(Stock stock);

}
