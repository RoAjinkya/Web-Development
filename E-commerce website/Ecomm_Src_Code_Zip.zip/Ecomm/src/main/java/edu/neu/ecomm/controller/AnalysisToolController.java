package edu.neu.ecomm.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.neu.ecomm.sevice.AnalysisToolService;
import edu.neu.ecomm.vo.Stock;
import edu.neu.ecomm.vo.Warehouse;

@Controller
public class AnalysisToolController {
	
	@Autowired
	private AnalysisToolService analysisToolService;
	@RequestMapping(value = "/getAnalysisTools",method = RequestMethod.GET )
	public ModelAndView getAnalysisTools(ModelMap model){
		Collection<ArrayList<Stock>> lists =analysisToolService.getAnalysisTools();
		//System.out.println(warehouse.toString());
		//return new ModelAndView("analysisTools", "command", new Warehouse());
	//	return new ModelAndView("redirect:/getWarehouse");
		
		System.out.println();
		 Iterator itr = lists.iterator();
		//while(itr.hasNext()) {
	        List<Stock> list1 =  (List<Stock>) itr.next();
			 System.out.println("In controller"+list1.toString() + " ");
	         model.put("lists", list1);
	         List<Stock> list2 =  (List<Stock>) itr.next();
	         model.put("list2", list2);
	         List<Stock> list3 =  (List<Stock>) itr.next();
	         model.put("list3", list3);
	         
	         
	         
	      //}
		
		 return new ModelAndView("analysisTools", "command", new Stock());
		
		//return "analysisTools";
			}
	

}
