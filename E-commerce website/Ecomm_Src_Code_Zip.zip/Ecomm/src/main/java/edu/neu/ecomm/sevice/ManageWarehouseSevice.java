package edu.neu.ecomm.sevice;

import java.util.Collection;

import edu.neu.ecomm.vo.Warehouse;

public interface ManageWarehouseSevice {

	void addWarehouse(Warehouse warehouse);

	Collection<Warehouse> getWarehouse(Warehouse warehouse);

	void deleteWarehouse(int id);

}
