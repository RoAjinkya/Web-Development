package edu.neu.ecomm.sevice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.neu.ecomm.dao.RegisterDAO;
import edu.neu.ecomm.dao.RegisterDAOImpl;
import edu.neu.ecomm.vo.User;

@Service
public class RegisterServiceImpl implements RegisterService{

	
	@Autowired
	private RegisterDAO registerDAO;
	
	

	@Override
	public void addUser(User user) {
		System.out.println("in serrvice");
		registerDAO.addStudent(user);
	}

}
