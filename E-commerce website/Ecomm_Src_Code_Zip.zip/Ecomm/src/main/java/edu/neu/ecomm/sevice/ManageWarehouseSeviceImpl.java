package edu.neu.ecomm.sevice;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.neu.ecomm.dao.ManageOrderDAO;
import edu.neu.ecomm.dao.ManageOrderDAOImpl;
import edu.neu.ecomm.dao.ManageWarehouseDAO;
import edu.neu.ecomm.vo.Warehouse;

@Service
public class ManageWarehouseSeviceImpl  implements ManageWarehouseSevice{

	
	@Autowired
	private ManageWarehouseDAO manageWarehouseDAO;

	@Override
	public void addWarehouse(Warehouse warehouse) {
		// TODO Auto-generated method stub
		manageWarehouseDAO.addWarehouse(warehouse);
		
	}

	@Override
	public Collection<Warehouse> getWarehouse(Warehouse warehouse) {
		// TODO Auto-generated method stub
		
		
		return manageWarehouseDAO.getWarehouse(warehouse);
	}

	@Override
	public void deleteWarehouse(int id) {
		// TODO Auto-generated method stub
		
		manageWarehouseDAO.deleteWarehouse(id);
		
	}
	
}
