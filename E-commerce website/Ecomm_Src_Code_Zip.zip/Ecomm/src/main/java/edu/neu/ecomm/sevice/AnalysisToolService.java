package edu.neu.ecomm.sevice;

import java.util.ArrayList;
import java.util.Collection;

import edu.neu.ecomm.vo.Stock;

public interface AnalysisToolService {

	Collection<ArrayList<Stock>> getAnalysisTools();

}
