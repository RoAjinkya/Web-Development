package edu.neu.ecomm.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

import edu.neu.ecomm.vo.Stock;

@Repository
public class AddStockDAOImpl implements AddStockDAO{

@Override
	public void addStock(Stock stock) {
		// TODO Auto-generated method stub
		
	
	try {
		final Session session = HibernetUtil.getHibernateSession();
		Transaction tx = session.beginTransaction();
		session.save(stock);
		 tx.commit();
		 session.close();
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

}
