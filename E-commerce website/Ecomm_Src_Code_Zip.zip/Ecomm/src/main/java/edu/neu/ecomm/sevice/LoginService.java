package edu.neu.ecomm.sevice;

import edu.neu.ecomm.vo.User;

public interface LoginService {

	User ValidateUser(User user);

}
