package edu.neu.ecomm.sevice;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.neu.ecomm.dao.ManageOrderDAO;
import edu.neu.ecomm.dao.ManageOrderDAOImpl;
import edu.neu.ecomm.dao.ManageVendersDAO;
import edu.neu.ecomm.vo.Venders;

@Service
public class ManageVendersServiceImpl implements ManageVendersService{

	@Autowired
	private ManageVendersDAO manageVendersDAO;

	
	@Override
	public void addVenders(Venders venders) {
		// TODO Auto-generated method stub
		
		manageVendersDAO.Addvenders(venders);
		
		
	}


	@Override
	public Collection<Venders> getVenders(Venders venders) {
		// TODO Auto-generated method stub
		Collection<Venders> listVenders = manageVendersDAO.getVenders();
		return listVenders;
	}


	@Override
	public void deleteVender(int id) {
		// TODO Auto-generated method stub
		manageVendersDAO.deleteVender(id);
		
	}


		
}
