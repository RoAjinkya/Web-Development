package edu.neu.ecomm.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.annotations.Cascade;
import org.springframework.stereotype.Repository;

import edu.neu.ecomm.vo.OrderIn;
import edu.neu.ecomm.vo.OrderProduct;
import edu.neu.ecomm.vo.Stock;
import edu.neu.ecomm.vo.User;
import edu.neu.ecomm.vo.Venders;
import edu.neu.ecomm.vo.Warehouse;

@Repository
public class ManageOrderDAOImpl implements ManageOrderDAO {

	@Override
	public Collection<OrderIn> getOrders(User user) {
		// TODO Auto-generated method stub
		
		
		Collection<OrderIn> listOfOrder = new ArrayList();
		try {
			final Session session = HibernetUtil.getHibernateSession();
			Transaction tx = session.beginTransaction();
			listOfOrder = session.createQuery("from OrderIn").list();
			 tx.commit();
			 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listOfOrder;
		
	}

	@Override
	public void deleteOrder(int id) {
		// TODO Auto-generated method stub
		//deleteOrderProduct(id);
		
		try {
			final Session session = HibernetUtil.getHibernateSession();
			Transaction tx = session.beginTransaction();

			OrderIn order = (OrderIn) session.get(OrderIn.class, id); 
			session.delete(order);
			
			tx.commit();
			 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		
	}
	
}

