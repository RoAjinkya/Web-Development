package edu.neu.ecomm.sevice;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.neu.ecomm.dao.BuyProductsDAO;
import edu.neu.ecomm.dao.BuyProductsDAOImpl;
import edu.neu.ecomm.dao.HibernetUtil;
import edu.neu.ecomm.vo.OrderIn;
import edu.neu.ecomm.vo.Stock;

@Service
public class BuyProductServiceImpl implements BuyProductService {
	@Autowired
	private BuyProductsDAO buyProductsDAO;

	@Override
	public Collection<Stock> getProducts() {
		// TODO Auto-generated method stub
		return buyProductsDAO.getProducts();
	}

	@Override
	public Collection<Stock> getCartProducts(List<Integer> getCartlist) {
		// TODO Auto-generated method stub
		return buyProductsDAO.getCartProducts(getCartlist);
	}

	@Override
	public void placeOrder(OrderIn order) {
		// TODO Auto-generated method stub
		 buyProductsDAO.placeOrder(order);
		/* String to = "abcd@gmail.com";
	      String from = "web@gmail.com";
	      String host = "localhost";
	      Properties properties = System.getProperties();
	      properties.setProperty("mail.smtp.host", host);
	      //final Session session = HibernetUtil.getHibernateSession();
	      Session session = Session.getDefaultInstance(properties);
	      
	      try {
	          // Create a default MimeMessage object.
	          MimeMessage message = new MimeMessage(session);

	          // Set From: header field of the header.
	          message.setFrom(new InternetAddress(from));

	          // Set To: header field of the header.
	          message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

	          // Set Subject: header field
	          message.setSubject("This is the Subject Line!");

	          // Now set the actual message
	          message.setText("This is actual message");

	          // Send message
	          Transport.send(message);
	          System.out.println("Sent message successfully....");
	       }catch (MessagingException mex) {
	          mex.printStackTrace();
	       }

	      */
		 
		 
		 
	}



}
