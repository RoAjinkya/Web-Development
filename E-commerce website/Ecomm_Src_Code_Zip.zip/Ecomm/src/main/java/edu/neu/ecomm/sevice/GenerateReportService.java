package edu.neu.ecomm.sevice;

public interface GenerateReportService {

}
