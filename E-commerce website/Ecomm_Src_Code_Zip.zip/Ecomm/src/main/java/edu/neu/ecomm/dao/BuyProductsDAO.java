package edu.neu.ecomm.dao;

import java.util.Collection;
import java.util.List;

import edu.neu.ecomm.vo.OrderIn;
import edu.neu.ecomm.vo.Stock;

public interface BuyProductsDAO {

	Collection<Stock> getProducts();

	Collection<Stock> getCartProducts(List<Integer> getCartlist);

	void placeOrder(OrderIn order);

}
