package edu.neu.ecomm.dao;

import org.springframework.stereotype.Repository;

@Repository
public class GenerateReportDAOImpl implements GenerateReportDAO {

}
