package edu.neu.ecomm.dao;

import java.util.ArrayList;
import java.util.Collection;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import edu.neu.ecomm.vo.Venders;
import edu.neu.ecomm.vo.Warehouse;

@Repository
public class ManageWarehouseDAOImpl implements ManageWarehouseDAO {

	@Override
	public void addWarehouse(Warehouse warehouse) {
		// TODO Auto-generated method stub
		try {
			final Session session = HibernetUtil.getHibernateSession();
			Transaction tx = session.beginTransaction();
			session.saveOrUpdate(warehouse);
			 tx.commit();
			 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Collection<Warehouse> getWarehouse(Warehouse warehouse) {
		// TODO Auto-generated method stub
		
		//String hql ="from Warehouse";
		Collection<Warehouse> WarehouseList = new ArrayList();
		try {
			final Session session = HibernetUtil.getHibernateSession();
			Transaction tx = session.beginTransaction();
			//session.save(venders);
			
			WarehouseList = session.createQuery("from Warehouse").list();
			 tx.commit();
			 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return WarehouseList;
		
		
	}

	@Override
	public void deleteWarehouse(int id) {
		// TODO Auto-generated method stub
		final Session session = HibernetUtil.getHibernateSession();
		Query q = session.createQuery("delete Warehouse where id = "+id);	
		
		try {
			Transaction tx = session.beginTransaction();

			q.executeUpdate();
			
			//session.save(warehouse);
			 tx.commit();
			 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
