package edu.neu.ecomm.controller;

import org.springframework.stereotype.Controller;

@Controller
public class GenerateReportController {

}
