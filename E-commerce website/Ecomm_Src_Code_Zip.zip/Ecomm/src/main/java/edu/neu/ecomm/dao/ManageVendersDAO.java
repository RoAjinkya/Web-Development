package edu.neu.ecomm.dao;

import java.util.Collection;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.neu.ecomm.vo.Venders;

public interface ManageVendersDAO {

	void Addvenders(Venders venders);

	Collection<Venders> getVenders();

	void deleteVender(int id);

	
}
