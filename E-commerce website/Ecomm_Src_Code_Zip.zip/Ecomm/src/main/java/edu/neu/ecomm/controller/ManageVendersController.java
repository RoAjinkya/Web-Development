package edu.neu.ecomm.controller;

import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.neu.ecomm.sevice.AddStockService;
import edu.neu.ecomm.sevice.ManageVendersService;
import edu.neu.ecomm.vo.Stock;
import edu.neu.ecomm.vo.Venders;

@Controller
public class ManageVendersController {

	@Autowired
	private ManageVendersService manageVendersService;
	
	@RequestMapping(value ="/addVenders", method = RequestMethod.POST )
	public String addvenders( @ModelAttribute("venderForm")@Valid Venders venders,  BindingResult bindingResult, ModelMap model){
		 Collection<Venders> listVenders = manageVendersService.getVenders(venders);
			System.out.println("llist of venders"+listVenders.toString());
			model.put("listVenders", listVenders);
		if (bindingResult.hasErrors()) {
			System.out.println("Error has occured");
			 model.addAttribute("command", new Venders());
			
			return("manageVenders");
		}
		
		manageVendersService.addVenders(venders);
	//	return new ModelAndView("redirect:/getVenders");
	return "redirect:/getVenders";	
	}
	
	@RequestMapping(value ="/getVenders", method = RequestMethod.GET )
	public String getvenders( @ModelAttribute("SpringWeb")Venders venders,  ModelMap model){
		Collection<Venders> listVenders = manageVendersService.getVenders(venders);
		System.out.println("llist of venders"+listVenders.toString());
		model.put("listVenders", listVenders);
		
		model.addAttribute("command", new Venders());
		 Venders vender = new Venders();
		 model.addAttribute("venderForm", vender);
		 return "manageVenders";	
		//return new ModelAndView("manageVenders", "command", new Venders());
			}
	
	
	@RequestMapping(value ="/deleteVender/{id}", method = RequestMethod.GET )
	public ModelAndView deletevenders( @ModelAttribute("SpringWeb")Venders venders,  @PathVariable("id")int id, ModelMap model){
		manageVendersService.deleteVender(id);
		return new ModelAndView("redirect:/getVenders");
			}
	
	
}
