package edu.neu.ecomm.sevice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.neu.ecomm.dao.AddStockDAO;
import edu.neu.ecomm.dao.AddStockDAOImpl;
import edu.neu.ecomm.vo.Stock;

@Service
public class AddStockServiceImpl implements AddStockService{

	
	@Autowired
	private AddStockDAO addStockDAO ;
	
	@Override
	public void addStock(Stock stock){
		
		addStockDAO.addStock(stock);
		
	}

}
