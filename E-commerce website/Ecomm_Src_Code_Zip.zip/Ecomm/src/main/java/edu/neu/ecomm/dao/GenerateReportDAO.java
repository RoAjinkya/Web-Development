package edu.neu.ecomm.dao;

public interface GenerateReportDAO {

}
