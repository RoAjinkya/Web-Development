package edu.neu.ecomm.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.neu.ecomm.sevice.AddStockService;
import edu.neu.ecomm.vo.Stock;
import edu.neu.ecomm.vo.User;

@Controller
@RequestMapping("/addstock")
public class AddStockController {
	
	@Autowired
	private AddStockService addStockService;
	
	@RequestMapping(method=RequestMethod.POST)
	public String addStock( @ModelAttribute("stockForm")@Valid Stock stock, BindingResult bindingResult,  ModelMap model)
	{
		
		if (bindingResult.hasErrors()) {
			System.out.println("Error has occured");
			 model.addAttribute("command", new Stock());
			return("addStock");
		}
		
		addStockService.addStock(stock);
		System.out.println("Came bACK");
		
		 model.addAttribute("name",stock.getProductName());
	      model.addAttribute("age", stock.getQuantity());
	      model.addAttribute("id", stock.getProductCategoryId());
	     
	      model.addAttribute("Product Name", stock.getProductName());
	      model.addAttribute("command", new Stock());
			
	      //return new ModelAndView("redirect:/goaddstock");
	      return "addStock";
		
	}
}
