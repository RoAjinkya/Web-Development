package edu.neu.ecomm.sevice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.neu.ecomm.dao.GenerateReportDAOImpl;

@Service
public class GenerateReportServiceImpl {

	@Autowired
	private GenerateReportDAOImpl generateReportDAO;
}
