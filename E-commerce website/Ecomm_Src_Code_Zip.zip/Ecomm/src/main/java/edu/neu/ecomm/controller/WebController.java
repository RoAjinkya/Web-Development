package edu.neu.ecomm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.neu.ecomm.vo.Stock;
import edu.neu.ecomm.vo.User;
import edu.neu.ecomm.vo.Venders;
import edu.neu.ecomm.vo.Warehouse;

@Controller
public class WebController {
	
	 @RequestMapping(value = "/redirect", method = RequestMethod.GET)
	   public String redirect(Model model) {
		 model.addAttribute("command", new User());
		 User user = new User();
			model.addAttribute("userForm", user);
       return "register";  	
	 }

	 @RequestMapping(value = "/goaddstock", method = RequestMethod.GET)
	   public String addstock(Model model) {
		 model.addAttribute("command", new Stock());
		 Stock stock = new Stock();
		 model.addAttribute("stockForm", stock);
		 return "addStock";
	     }
	 
	 @RequestMapping(value = "/gomanageVender", method = RequestMethod.GET)
	   public String addvenders(Model model) {
		 model.addAttribute("command", new Venders());
		 Venders vender = new Venders();
		 model.addAttribute("venderForm", vender);
		 return "manageVenders";
		// return new ModelAndView("manageVenders", "command", new Venders());
	     }
	 
	 @RequestMapping(value = "/gomanageWarehouse", method = RequestMethod.GET)
	   public ModelAndView addwarehouse() {
		 return new ModelAndView("manageWarehouse", "command", new Warehouse());
	     }
	 
	 
	 @RequestMapping(value = "/aboutus", method = RequestMethod.GET)
	   public String aboutus(Model model) {
		 model.addAttribute("command", new User());
		 return "aboutus";  	
	 }
	 
	 @RequestMapping(value = "/contactus", method = RequestMethod.GET)
	   public String contactus(Model model) {
		 model.addAttribute("command", new User());
		 return "contactus";  	
	 }
	 
	 
	 
	 
	 
}
