package edu.neu.ecomm.dao;

import java.awt.Container;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.management.monitor.StringMonitorMBean;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import edu.neu.ecomm.vo.OrderIn;
import edu.neu.ecomm.vo.Stock;

@Repository
public class BuyProductsDAOImpl implements BuyProductsDAO {

	@Override
	public Collection<Stock> getProducts() {
		// TODO Auto-generated method stub
		Collection<Stock> listOfStock = new ArrayList();
		try {
			final Session session = HibernetUtil.getHibernateSession();
			Transaction tx = session.beginTransaction();
			listOfStock = session.createQuery("from Stock").list();
			 tx.commit();
			 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listOfStock;
	}

	@Override
	public Collection<Stock> getCartProducts(List<Integer> getCartlist) {
		// TODO Auto-generated method stub
		String condition = getCartlist.toString();
		condition = condition.substring(1, condition.length()-1);
		System.out.println("SubString function"+condition);
		
		Collection<Stock> listOfStock = new ArrayList();
		Session session;
		try {
			session = HibernetUtil.getHibernateSession();
			Transaction tx = session.beginTransaction();
			String hql = "from Stock s where s.id in ("+ condition+")";
			
			//System.out.println("hql" +hql);
			
			listOfStock = session.createQuery(hql).list();
			 tx.commit();
			 session.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 System.out.println("list of stock s"+listOfStock.toString());
		 return listOfStock;
	}

	@Override
	public void placeOrder(OrderIn order) {
		// TODO Auto-generated method stub
		
		System.out.println("in DAO impl"+order.toString());
		 try {
			final Session session = HibernetUtil.getHibernateSession();
				Transaction tx = session.beginTransaction();
				session.save(order);
				 tx.commit();
				 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			}

}
