package edu.neu.ecomm.dao;

import java.util.ArrayList;
import java.util.Collection;

import edu.neu.ecomm.vo.Stock;

public interface AnalysisToolDAO {

	Collection<ArrayList<Stock>> getAnalysisTools();

}
