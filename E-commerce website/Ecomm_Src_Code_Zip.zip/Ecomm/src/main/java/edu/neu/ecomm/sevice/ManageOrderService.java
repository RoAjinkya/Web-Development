package edu.neu.ecomm.sevice;

import java.util.Collection;

import edu.neu.ecomm.vo.OrderIn;
import edu.neu.ecomm.vo.User;

public interface ManageOrderService {

	Collection<OrderIn> getOrder(User user);

	void deleteVender(int id);

}
