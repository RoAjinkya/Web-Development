package edu.neu.ecomm.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import edu.neu.ecomm.vo.Venders;
@Repository
public class ManageVendersDAOImpl implements ManageVendersDAO{

	@Override
	public void Addvenders(Venders venders) {
		// TODO Auto-generated method stub
		
	System.out.println("in DAO" + venders.toString());
	try {
		final Session session = HibernetUtil.getHibernateSession();
		Transaction tx = session.beginTransaction();
		session.saveOrUpdate(venders);
		 tx.commit();
		 session.close();
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}

	@Override
	public Collection<Venders> getVenders() {
		// TODO Auto-generated method stub
		//System.out.println("in DAO" + venders.toString());
		String hql ="from Venders";
		Collection<Venders> listVenders = new ArrayList();
		try {
			final Session session = HibernetUtil.getHibernateSession();
			Transaction tx = session.beginTransaction();
			//session.save(venders);
			
			listVenders = session.createQuery(hql).list();
			 tx.commit();
			 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listVenders;
	}

	@Override
	public void deleteVender(int id) {
		// TODO Auto-generated method stub
		
		try {
			final Session session = HibernetUtil.getHibernateSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("delete Venders where id = "+id);
			q.executeUpdate();
			
			//session.save(warehouse);
			 tx.commit();
			 session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
