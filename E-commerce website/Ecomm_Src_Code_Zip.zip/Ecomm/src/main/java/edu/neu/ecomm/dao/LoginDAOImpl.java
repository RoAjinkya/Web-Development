package edu.neu.ecomm.dao;

import java.util.List;

import javax.management.Query;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.neu.ecomm.vo.User;

@Repository
public class LoginDAOImpl implements LoginDAO {

	@Override
	public User ValidateUser(User user) {
		// TODO Auto-generated method stub
		
		
		
		//final SessionFactory sessionFactory1 = new Configuration().configure().buildSessionFactory();;
		
		final Session session = HibernetUtil.getHibernateSession();
		Transaction tx = session.beginTransaction();
		
		//Query query=  (Query) session.createQuery(hql);
	//	session.save(user);
		//List results = ((org.hibernate.Query) query).list();
		User userreturn = new User();
		
		 
		try {
			String hql = "from User where username= '"+user.getUsername()+"' and password='"+user.getPassword()+"'";
			System.out.println("HQL"+hql);
			List<User> user1 = session.createQuery(hql).list();
			 tx.commit();
			 session.close();
			 
			System.out.println(" xtxs"+user1.toString());
			if(user1.size()!=0)
				userreturn = user1.get(0);
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return userreturn;
		 
	//	return sessionFactory.getCurrentSession().createQuery("from Student").list();
	}

}
