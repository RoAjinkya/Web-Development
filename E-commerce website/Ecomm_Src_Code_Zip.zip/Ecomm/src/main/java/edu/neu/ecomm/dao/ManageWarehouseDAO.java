package edu.neu.ecomm.dao;

import java.util.Collection;

import edu.neu.ecomm.vo.Warehouse;

public interface ManageWarehouseDAO {

	void addWarehouse(Warehouse warehouse);

	Collection<Warehouse> getWarehouse(Warehouse warehouse);

	void deleteWarehouse(int id);

}
