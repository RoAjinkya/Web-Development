package edu.neu.ecomm.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import edu.neu.ecomm.sevice.BuyProductService;
import edu.neu.ecomm.vo.OrderIn;
import edu.neu.ecomm.vo.OrderProduct;
import edu.neu.ecomm.vo.Stock;
import edu.neu.ecomm.vo.User;

@Controller
public class BuyProdctController {
	
	List<Integer> Cartlist =new ArrayList();
	
	@Autowired
	private BuyProductService buyProductService;
	
	@RequestMapping(value = "/getProducts",method= RequestMethod.GET)
	public ModelAndView getProducts(ModelMap model,HttpServletRequest request,HttpSession session){
	
		Collection<Stock> listofStock = buyProductService.getProducts();
	
		Integer UserId  =  (Integer) session.getAttribute("UserId");
		
		System.out.println("Username in get Product"+UserId);
			
		
		model.put("listOfStock", listofStock);
		
		return new ModelAndView("products", "command", new Stock());
		
		
		
	}

	@RequestMapping(value = "/addtoCart/{id}",method= RequestMethod.GET)
	public ModelAndView addProductsToCart(@PathVariable("id")int id ,ModelMap model,HttpSession session){
		Cartlist.add(id);
		Integer UserId  = (Integer) session.getAttribute("UserId");
		System.out.println("Username in add to cart"+UserId);
		model.put("Cartlist", Cartlist);
		return new ModelAndView("redirect:/getProducts");
	}
	
	@RequestMapping(value = "/showCart",method= RequestMethod.GET)
	public ModelAndView showProductsToCart(ModelMap model,HttpSession session ){
	
		Integer UserId  = (Integer) session.getAttribute("UserId");
		List<Integer> getCartlist= (List<Integer>) model.get("Cartlist");
		Collection<Stock> listofStock = buyProductService.getCartProducts(Cartlist);
		model.put("listOfStock", listofStock);
		session.setAttribute("listOfStock", listofStock);
		return new ModelAndView("cart", "command", new OrderIn());
	}
	
	
	
	
	@RequestMapping(value = "/placeOrder",method=RequestMethod.POST)
	public ModelAndView addStock( @ModelAttribute("SpringWeb")OrderIn order, ModelMap model, HttpServletRequest request,HttpSession session)
	{
		
		List<Stock> listStock = (List<Stock>) session.getAttribute("listOfStock");
		User user= (User)model.get("user");
		Collection<OrderProduct> setofStock = new ArrayList<OrderProduct>();
		for(int i=0;i<listStock.size();i++)
		{
			OrderProduct orderProduct = new OrderProduct();
			
			orderProduct.setProductName(listStock.get(i).getProductName());
			orderProduct.setProductPrice(listStock.get(i).getProductPrice());
			orderProduct.setProductCategoryId(listStock.get(i).getProductCategoryId());
			orderProduct.setProductSubCategoryId(listStock.get(i).getProductSubCategoryId());
			orderProduct.setQuantity(listStock.get(i).getQuantity());
			
			setofStock.add(orderProduct);
		}
		
		String totalOrderValue = request.getParameter("totalOrderValue");
		System.out.println(totalOrderValue);
		order.setOrderCost(Float.parseFloat(totalOrderValue));
		Integer UserId  = (Integer) session.getAttribute("UserId");
		System.out.println("Username in plcae order"+UserId);
		
		order.setCustomerId(UserId);
		
		order.setListOfSTockOrder(setofStock);
		Date date = new Date();
		order.setOrderStatus("open");
		order.setOrderDate(date);
		
	
		
		buyProductService.placeOrder(order);
		session.removeAttribute("listOfStock");
		model.remove("Cartlist");
		
		
	      return new ModelAndView("redirect:/getOrders");
		
	}
	
	
}
