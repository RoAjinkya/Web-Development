package edu.neu.ecomm.sevice;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.neu.ecomm.dao.ManageOrderDAO;
import edu.neu.ecomm.dao.ManageOrderDAOImpl;
import edu.neu.ecomm.vo.OrderIn;
import edu.neu.ecomm.vo.User;

@Service
public class ManageOrderServiceImpl  implements ManageOrderService{

	@Autowired
	private ManageOrderDAO manageOrderDAO;

	@Override
	public Collection<OrderIn> getOrder(User user) {
		// TODO Auto-generated method stub
		return manageOrderDAO.getOrders(user);
	}

	@Override
	public void deleteVender(int id) {
		// TODO Auto-generated method stub
		manageOrderDAO.deleteOrder(id);
	}
}
