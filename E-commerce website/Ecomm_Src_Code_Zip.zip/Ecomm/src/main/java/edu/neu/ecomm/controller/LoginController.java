package edu.neu.ecomm.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import edu.neu.ecomm.sevice.LoginService;
import edu.neu.ecomm.vo.Stock;
import edu.neu.ecomm.vo.User;

@Controller
public class LoginController {
	
	@Autowired
	private LoginService loginService;
	
	ModelAndView modelAndView=new ModelAndView();
	
@RequestMapping(value = "/login",method=RequestMethod.POST)
	public ModelAndView login(HttpServletRequest request, ModelMap model ,HttpSession session, RedirectAttributes redir){
		User user = new User() ;
		user.setUsername(request.getParameter("usename"));
		user.setPassword(request.getParameter("password"));
		//user.setId(1);
		//user.setFirstName("firstname");
		System.out.println("I am here"+user.toString());
		User user1 =new User();
		user1=	loginService.ValidateUser(user);
		if(user1.getRole() == null)
		{
			String ErrorString = "Bad Credentials";
			model.addAttribute("ErrorCred", ErrorString);
			
			return new ModelAndView("redirect:/");
			
		}
		
		System.out.println(user1.toString());
		System.out.println(user1.getRole());
		String Role =user1.getRole(); 	
		model.put("User", user1);
		
	
		  session = request.getSession();
		   // String username = (String)request.getAttribute("un");
		    session.setAttribute("UserId", user1.getId());
		    
		System.out.println("Login  controller"+user1.toString());
		
		if(Role.equalsIgnoreCase("user"))
		{
		//return "result";
			
			 modelAndView.setViewName("redirect:/getProducts");
			    redir.addFlashAttribute("User",user1);
			    return modelAndView;
		//return new ModelAndView("redirect:/getProducts");
		}
		if(Role.equalsIgnoreCase("admin"))
		{
			//return new ModelAndView("redirect:/goaddstock");
		model.addAttribute("stockForm", new Stock());
			return new ModelAndView("addStock", "command", new Stock());
		}
		if(Role.equalsIgnoreCase("analyst"))
		{
			return new ModelAndView("redirect:/getAnalysisTools");
		}
		else
		return new ModelAndView("redirect:/");
	}
	
	@RequestMapping(value= "/logout",method= RequestMethod.GET)
public ModelAndView logout(HttpServletRequest request, ModelMap model ,HttpSession session){
		session.invalidate();
		return new ModelAndView("redirect:/");
	
}

}
