package edu.neu.ecomm.controller;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.neu.ecomm.sevice.ManageVendersService;
import edu.neu.ecomm.sevice.ManageWarehouseSevice;
import edu.neu.ecomm.vo.Venders;
import edu.neu.ecomm.vo.Warehouse;

@Controller
public class ManageWarehouseController {

	@Autowired
	private ManageWarehouseSevice manageWareouseService;
	@RequestMapping(value = "/addWarehouse",method = RequestMethod.POST )
	public String addWarehouse( @ModelAttribute("warehosueForm")@Valid Warehouse warehouse ,BindingResult bindingResult , ModelMap model){
		
		Collection<Warehouse> listWarehouses = manageWareouseService.getWarehouse(warehouse);
		model.put("listWarehouses", listWarehouses);
	
		if (bindingResult.hasErrors()) {
			System.out.println("Error has occured");
			 model.addAttribute("command", new Venders());
			 	return("manageWarehouse");
		}
		manageWareouseService.addWarehouse(warehouse);
		System.out.println(warehouse.toString());
		//return new ModelAndView("manageWarehouse", "command", new Warehouse());
		return("redirect:/getWarehouse");
		
			}
	
	
	@RequestMapping(value = "/getWarehouse",method = RequestMethod.GET )
	public String getWsarehouse( @ModelAttribute("SpringWeb")Warehouse warehouse ,  ModelMap model){
		Collection<Warehouse> listWarehouses = manageWareouseService.getWarehouse(warehouse);
		
		model.put("listWarehouses", listWarehouses);
		System.out.println(listWarehouses.toString());
		
		
		 model.addAttribute("command", new Warehouse());
		 Warehouse warehouseq = new Warehouse();
		 model.addAttribute("warehosueForm", warehouseq);
		 return "manageWarehouse";
		//return new ModelAndView("manageWarehouse", "command", new Warehouse());
		
		
			}
	
	
	@RequestMapping(value = "/deleteWarehouse/{id}",method = RequestMethod.GET )
	public ModelAndView deleteVender( @PathVariable("id")int id, @ModelAttribute("SpringWeb")Warehouse warehouse,  ModelMap model){
		manageWareouseService.deleteWarehouse(id);
		//System.out.println(warehouse.toString());
		//return new ModelAndView("manageWarehouse", "command", new Warehouse());
		return new ModelAndView("redirect:/getWarehouse");
		
			}
	
}
