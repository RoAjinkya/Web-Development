package edu.neu.ecomm.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.neu.ecomm.sevice.RegisterService;
import edu.neu.ecomm.vo.User;

@Controller
@RequestMapping("/register")
public class RegisterController {
	
	 @Autowired
	@Value("10")
	private Integer pingFrequency;
	@Autowired
	private RegisterService registerService;
	
	
	@RequestMapping(method=RequestMethod.POST)
	public String addUser(@ModelAttribute("userForm")@Valid User user, BindingResult bindingResult, 
			   Model model) {
		if (bindingResult.hasErrors()) {
			System.out.println("Error has occured");
			 model.addAttribute("command", new User());
			return("register");
		}
		
		
		System.out.println("incontroller");
		user.setRoll("user");
		registerService.addUser(user);
		System.out.println("in controller after 123");
		
		 model.addAttribute("name", user.getUsername());
	      model.addAttribute("age", user.getFirstName());
	      model.addAttribute("id", user.getId());
	      return("result");
	      //return new ModelAndView("result", "command", new User());
	}
	

}
