package edu.neu.ecomm.dao;

import edu.neu.ecomm.vo.User;

public interface LoginDAO {

	User ValidateUser(User user);

}
