package edu.neu.ecomm.controller;

import java.util.Collection;

import javax.persistence.criteria.Order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import edu.neu.ecomm.sevice.ManageOrderService;
import edu.neu.ecomm.vo.OrderIn;
import edu.neu.ecomm.vo.Stock;
import edu.neu.ecomm.vo.User;
import edu.neu.ecomm.vo.Venders;

@Controller
public class ManageOrderController {

	@Autowired
	private ManageOrderService manageOrderService;
	
	@RequestMapping(value = "/getOrders",method= RequestMethod.GET)
	public ModelAndView getProducts(ModelMap model,User user){
	Collection<OrderIn> listOfOrder = manageOrderService.getOrder(user);
		model.put("listOfOrder", listOfOrder);
		System.out.println("list of order "+ listOfOrder);
		
		return new ModelAndView("order", "command", new OrderIn());
	}
	
	@RequestMapping(value ="/deleteOrder/{id}", method = RequestMethod.GET )
	public ModelAndView deleteOrder( @ModelAttribute("SpringWeb")OrderIn order,  @PathVariable("id")int id, ModelMap model){
		manageOrderService.deleteVender(id);
		return new ModelAndView("redirect:/getOrders");
			}
	
	
	
}
