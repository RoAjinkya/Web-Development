package edu.neu.ecomm.dao;

import edu.neu.ecomm.vo.User;

public interface RegisterDAO {

	public void addStudent(User user);
	
}
