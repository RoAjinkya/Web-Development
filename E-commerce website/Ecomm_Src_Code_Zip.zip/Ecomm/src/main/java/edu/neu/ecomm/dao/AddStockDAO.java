package edu.neu.ecomm.dao;

import edu.neu.ecomm.vo.Stock;

public interface AddStockDAO {

	void addStock(Stock stock);

}
