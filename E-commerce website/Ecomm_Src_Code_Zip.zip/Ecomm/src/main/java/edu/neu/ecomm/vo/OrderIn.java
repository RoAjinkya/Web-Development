package edu.neu.ecomm.vo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
public class OrderIn {

	@Id @GeneratedValue
	private int orderId;
	private int customerId;
	private Date orderDate;
	private String orderStatus;
	private Float orderCost;
	@ElementCollection
	@JoinTable(name="Order_Product",joinColumns=@JoinColumn(name="Order_Id"))
	@GenericGenerator(name="hilo-gen",strategy="hilo")
	@CollectionId(columns = { @Column(name="orderProducts_ID") }, generator = "hilo-gen", type = @Type(type="long"))
	private Collection<OrderProduct> listOfSTockOrder =new ArrayList<OrderProduct>();
	
	public Float getOrderCost() {
		return orderCost;
	}
	public void setOrderCost(Float orderCost) {
		this.orderCost = orderCost;
	}
	
	
	
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
		

	public Collection<OrderProduct> getListOfSTockOrder() {
		return listOfSTockOrder;
	}
	public void setListOfSTockOrder(Collection<OrderProduct> listOfSTockOrder) {
		this.listOfSTockOrder = listOfSTockOrder;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	@Override
	public String toString() {
		return "Order [id=" + orderId + ", orderProductId="+ " "+", customerId=" + customerId + ", date="
				+ orderDate + ", orderStatus=" + orderStatus + ", orderCost=" + orderCost + ", listOfSTockOrder="
				+ listOfSTockOrder 
				+ "]";
	}
	
	
	
	
	
}
