package edu.neu.ecomm.vo;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
public class Stock {

	@Id @GeneratedValue
	private int id;
	@NotNull
	@Size(min=1,max=15)
	private String productName;
	@NotNull
	private Integer productCategoryId;
	@NotNull
	private Integer productSubCategoryId;
	@Lob
	@NotNull
	@Min(1)
	private Integer quantity;
	@NotNull
	@Size(min=1,max=15)
	private String supplierName;
	@NotNull
	@Size(min=1,max=15)
	private String warehouseName;
	@Lob
	@NotNull
	@Size(min=1,max=15)
	private String productDesc;
	@NotNull
	@Min(1)
	private Float productPrice;
	//@DateTimeFormat(pattern = "MM/dd/yyyy")
	@NotNull
	private Date dateTime;
    //private java.sql.Date dateTime;
	//private Date date;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	public Integer getProductCategoryId() {
		return productCategoryId;
	}
	public void setProductCategoryId(Integer productCategoryId) {
		this.productCategoryId = productCategoryId;
	}
	public Integer getProductSubCategoryId() {
		return productSubCategoryId;
	}
	public void setProductSubCategoryId(Integer productSubCategoryId) {
		this.productSubCategoryId = productSubCategoryId;
	}

	
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public Float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Float productPrice) {
		this.productPrice = productPrice;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getWarehouseName() {
		return warehouseName;
	}
	public void setWarehouseName(String warehouseName) {
		this.warehouseName = warehouseName;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	@Override
	public String toString() {
		return "Stock [id=" + id + ", productName=" + productName + ", productCategoryId=" + productCategoryId
				+ ", productSubCategoryId=" + productSubCategoryId + ", quantity=" + quantity + ", supplierName="
				+ supplierName + ", warehouseName=" + warehouseName + ", productDesc=" + productDesc + ", productPrice="
				+ productPrice + ", dateTime=" + dateTime + "]";
	}

	
	
	
}
